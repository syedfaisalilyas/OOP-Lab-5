﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uams.BL
{
    class DegreeProgram
    {
        public string degreeName;
        public float degreeDuration;
        public int seats;
        public double merit;
        public List<Subject> subjects = new List<Subject>();
        public DegreeProgram() { }
        public DegreeProgram(string degreeName, float degreeDuration, int seats)
        {
            this.degreeName = degreeName;
            this.degreeDuration = degreeDuration;
            this.seats = seats;

        }
        public DegreeProgram(string degreeName)
        {
            this.degreeName = degreeName;

            this.degreeDuration = 0;
            this.seats = 0;
        }
    }
}
