﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uams.BL
{
    class Student
    {
        public string name;
        public int age;
        public double fscMarks;
        public double ecatMarks;
        public double merit;
        public DegreeProgram RegisteredProgram = new DegreeProgram();
        public List<DegreeProgram> preferences = new List<DegreeProgram>();
        public List<Subject> registeredSubjects = new List<Subject>();
        public bool isRegistered = false;
        public Student() { }

        public Student(string name, int age, double fscMarks, double ecatMarks)
        {
            this.name = name;
            this.age = age;
            this.fscMarks = fscMarks;
            this.ecatMarks = ecatMarks;

        }
        public void AddPreferenceOfStudent(DegreeProgram d1)
        {
            preferences.Add(d1);
        }
        public Student(string name, int age, double fscMarks, double ecatMarks, double merit)
        {
            this.name = name;
            this.age = age;
            this.fscMarks = fscMarks;
            this.ecatMarks = ecatMarks;
            this.merit = merit;

        }
        public double calculateMerit()
        {
            merit = (fscMarks * 0.6 + ecatMarks * 0.4);
            return merit;
        }
        public int getcredithours()
        {
            int count = 0;
            for (int i = 0; i < registeredSubjects.Count; i++)
            {
                count += registeredSubjects[i].creditHours;
            }
            return count;
        }
        public void GenerateMeritList()
        {
            double merit = calculateMerit();
            int count = 0;
            for (int i = 0; i < preferences.Count; i++)
            {
                if (merit >= preferences[i].merit)
                {
                    count++;
                    RegisteredProgram = preferences[i];
                    isRegistered = true;
                    break;
                }
            }
            if (count == 1)
            {
                Console.WriteLine(" {0} got admission in {1}", name, RegisteredProgram.degreeName);
            }

            if (isRegistered == false)
            {
                Console.WriteLine(" {0} did not get admission", name);
            }
        }
        public bool RegisterSubject(string subCode)
        {
            bool isSubjectRegister = false;
            int creditHour = getcredithours();
            if (creditHour == 9)
            {
                isSubjectRegister = false;
            }
            else
            {
                for (int i = 0; i < preferences.Count; i++)
                {
                    if (isSubjectRegister == true && RegisteredProgram.degreeName == preferences[i].degreeName)
                    {
                        for (int j = 0; j < registeredSubjects.Count; j++)
                        {
                            registeredSubjects.Add(preferences[i].subjects[j]);
                            isSubjectRegister = true;
                        }
                    }
                }
            }
            return isSubjectRegister;
        }
        public float CalculateFee()
        {
            int ch = getcredithours();
            float fee = ch * 2000;
            return fee;
        }
    }
}
