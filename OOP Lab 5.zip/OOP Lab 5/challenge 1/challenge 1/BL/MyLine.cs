﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace challenge_1.BL
{
    class MyLine
    {
        public MyPoint begin;
        public MyPoint end;
      
       public MyLine()
        {

        }
       public MyLine(MyPoint begin,MyPoint end)
        {
            this.begin = begin;
            this.end = end;
        }
        
        public MyPoint getBegin()
        {
            return begin;
        }

        public MyPoint getEnd()
        {
            return end;
        }

        public void setEnd(MyPoint end)
        {
            this.end = end;
        }

        public double getlength()
        {
            return begin.distancewithObject(end);
        }

        public double getgradient()
        {
            if(end.getX() == begin.getX())
            {
                throw new DivideByZeroException();
            }
            return (end.getY() - begin.getY()) / (end.getX() - begin.getY());
        }

    }
}
