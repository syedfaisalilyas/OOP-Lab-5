﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace challenge_1.BL
{
    class MyPoint
    {
       public int x;
       public int y;

        MyPoint()
        {
            x = 0;
            y = 0;
        }

       public MyPoint(int x,int y)
        {
            this.x = x;
            this.y = y;
        }

        public int getX()
        {
            return x;
        }

        public int getY()
        {
            return y;
        }

        public void SetX(int x)
        {
            this.x = x;
        }
        public void SetY(int y)
        {
            this.y = y;
        }

        public void SetXY(int X,int Y)
        {
            X = x;
            Y = y;
        }

        public double distancewithcords(int X,int Y)
        {
            double d;
            d = Math.Sqrt(Math.Pow(X - x, 2) + Math.Pow(Y - y, 2));
            return d;
        }

        public double distancewithObject(MyPoint another)
        {
            return distancewithcords(another.x, another.y);
        }

        public double distancefromzero()
        {
        return distancewithcords(0,0);
        }
    }
}
