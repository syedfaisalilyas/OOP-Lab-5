﻿using challenge_1.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace challenge_1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int choice;
            while (true)
            {
                MyLine Line = new MyLine();
                Console.WriteLine("Menu:");
                Console.WriteLine("1. Make a Line");
                Console.WriteLine("2. Update the begin point");
                Console.WriteLine("3. Update the end point");
                Console.WriteLine("4. Show the begin point");
                Console.WriteLine("5. Show the end point");
                Console.WriteLine("6. Get the length of the line");
                Console.WriteLine("7. Get the gradient of the line");
                Console.WriteLine("8. Find the distance of begin point from zero coordinates");
                Console.WriteLine("9. Find the distance of end point from zero coordinates");
                Console.WriteLine("10. Exit");

                // Get user choice
                Console.Write("Enter your choice (1-10): ");
                choice = int.Parse(Console.ReadLine());

      
                switch (choice)
                {
                    case 1:
                        // Make a Line
                        Console.Write("Enter the x-coordinate of the begin point: ");
                        int beginX = int.Parse(Console.ReadLine());
                        Console.Write("Enter the y-coordinate of the begin point: ");
                        int beginY = int.Parse(Console.ReadLine());
                        MyPoint begin = new MyPoint(beginX, beginY);
                        Console.Write("Enter the x-coordinate of the end point: ");
                        int endX = int.Parse(Console.ReadLine());
                        Console.Write("Enter the y-coordinate of the end point: ");
                        int endY = int.Parse(Console.ReadLine());
                        MyPoint end = new MyPoint(endX, endY);
                        MyLine line = new MyLine(begin, end);
                        Console.WriteLine("Line created: " + line);
                        break;
                    case 2:
                        // Update the begin point
                        Console.Write("Enter the x-coordinate of the new begin point: ");
                        int newBeginX = int.Parse(Console.ReadLine());
                        Console.Write("Enter the y-coordinate of the new begin point: ");
                        int newBeginY = int.Parse(Console.ReadLine());
                        MyPoint newBegin = new MyPoint(newBeginX, newBeginY);
                        newBegin.SetXY(newBeginX, newBeginY);
                        Console.WriteLine("Begin point updated: " + newBegin);
                        break;
                    case 3:
                        // Update the end point
                        Console.Write("Enter the x-coordinate of the new end point: ");
                        int newEndX = int.Parse(Console.ReadLine());
                        Console.Write("Enter the y-coordinate of the new end point: ");
                        int newEndY = int.Parse(Console.ReadLine());
                        MyPoint newend = new MyPoint(newEndX, newEndY);
                        newend.SetXY(newEndX, newEndY);
                        Console.WriteLine("End point updated: " + newend);
                        break;
                    case 4:
                        // Show the begin point
                        Console.WriteLine("Begin point: " + Line.getBegin().x + Line.getBegin().y)  ;
                        break;
                    case 5:
                        // Show the end point
                        Console.WriteLine("End point: " + Line.getEnd().x + Line.getEnd().y);
                        break;
                    case 6:
                        // Get the Length of the line
                        double length = Line.getlength();
                        Console.WriteLine("Length of the line: " + length);
                        break;
                    case 7:
                        // Get the Gradient of the Line
                        double gradient = Line.getgradient();
                        Console.WriteLine("Gradient of the line: " + gradient);
                        break;
                    case 8:
                        // Find the distance of begin point from zero coordinates

                        double beginDistanceFromZero = Line.begin.distancefromzero(); 
                        Console.WriteLine("Distance of begin point from zero coordinates: " + beginDistanceFromZero);
                        break;
                    case 9:
                        // Find the distance of end point from zero coordinates
                        double endDistanceFromZero = Line.end.distancefromzero();
                        Console.WriteLine("Distance of end point from zero coordinates: " + endDistanceFromZero);
                        break;
                    case 10:
                        // Exit
                        Console.WriteLine("Exiting...");
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a valid choice.");
                        break;
                }
            }
        }
    }
}
