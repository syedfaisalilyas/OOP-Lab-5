﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_2.BL
{

    class Product
    {
        public string product_name;
        public string product_category;
        public int product_price;
        public int product_quantity;
        public int stock_quantity;
        public int minimum_stock_quantity;
        public Product()
        {
            product_name = " ";
            product_category = " ";
            product_price = 0;
            stock_quantity = 0;
            minimum_stock_quantity = 0;
        }
        public Product(string pn, string pc, int pp, int sq, int msq)
        {
            product_name = pn;
            product_category = pc;
            product_price = pp;
            stock_quantity = sq;
            minimum_stock_quantity = msq;
        }

        public void display_product()
        {
            Console.WriteLine("Product Name: " + product_name);
            Console.WriteLine("Product Category: " + product_category);
            Console.WriteLine("Product Price: " + product_price);
            Console.WriteLine("Stock Quantity: " + stock_quantity);
            Console.WriteLine("Minimum Stock Quantity: " + minimum_stock_quantity);

        }
        public int Sales_tax()
        {
            int sales_tax = 0;
            if (product_category == "Grocery")
            {
                sales_tax = (product_price * 10) / 100;
            }
            else if (product_category == "Fruit")
            {
                sales_tax = (product_price * 5) / 100;

            }
            else
            {
                sales_tax = (product_price * 15) / 100;
            }
            return sales_tax;
        }

        public bool IsNeeded()
        {
            bool order = false;
            if (stock_quantity < minimum_stock_quantity)
            {
                order = true;
            }
            return order;
        }

    }
}
