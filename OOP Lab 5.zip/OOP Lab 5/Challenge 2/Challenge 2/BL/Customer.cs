﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_2.BL
{
    class Customer
    {
        public string customerName;
        public string address;
        public double contactNumber;
        static List<Product> product = new List<Product>();
        public List<Product> getProduct()
        {
            return product;
        }

        public Customer() { 
        }
        public Customer(string customerName, string address, double contactNumber)
        {
            this.customerName = customerName;
            this.address = address;
            this.contactNumber = contactNumber;
        }
        public Customer(List<Product> p)
        {
            product = p;
        }
        public void AddProdcut(Product p)
        {
            product.Add(p);
        }

        public Customer(string customerName, string address, double contactNumber, List<Product> product)
        {
            this.customerName = customerName;
            this.address = address;
            this.contactNumber = contactNumber;
            this.product = product;
        }

        public void addProduct(Product p)
        {
            product.Add(p);
        }
        public void BuyProduct(Product product,int quantity)
        {
            if(product.product_quantity>=quantity)
            {
                product.product_quantity -= quantity;
                Console.WriteLine("Product bought successfully!");
            }
            else
            {
                Console.WriteLine("Not enough stock!");
            }
    }

        public void GenerateInvoice(List<Product> products)
        {
            double totalPrice = 0;
            foreach (Product p in products)
            {
                totalPrice += p.product_price * p.product_quantity;
                double salesTax = p.Sales_tax();
                Console.WriteLine(p.product_name + " x " + p.product_quantity + " = " + (p.product_price * p.product_quantity).ToString("0.00") + " + " + salesTax.ToString("0.00") + " (sales tax)");
            }
            Console.WriteLine("Total Price: " + totalPrice.ToString("0.00"));
        }
       
    }
}
