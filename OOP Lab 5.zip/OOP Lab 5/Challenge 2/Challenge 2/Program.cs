﻿using Challenge_2.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Threading.Tasks;

namespace Challenge_2
{
    class Program
    {
        static void Main(string[] args)
        {

            int currentSelection = 1;
            while (true)
            {
                if (currentSelection == 1)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");
                }
                Console.WriteLine("   Sign Up");
                if (currentSelection == 2)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");

                }
                Console.WriteLine("   Sign In");
                if (currentSelection == 3)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");
                }
                Console.WriteLine("   Exit");

                // handle user input

                ConsoleKey keyy = Console.ReadKey().Key;
                if (keyy == ConsoleKey.UpArrow)
                { // up arrow key
                    if (currentSelection > 1)
                    {
                        currentSelection--;
                    }
                    else if (currentSelection == 1)
                    {
                        currentSelection = 3;
                    }
                }

                else if (keyy == ConsoleKey.DownArrow)
                { // down arrow key
                    if (currentSelection < 3)
                    {
                        currentSelection++;
                    }
                    else if (currentSelection == 3)
                    {
                        currentSelection = 1;
                    }
                }

                else if (keyy == ConsoleKey.Enter)
                { // enter key
                    if (currentSelection == 1)
                    {
                        signup();
                        Console.ReadKey();
                    }
                    else if (currentSelection == 2)
                    {
                        signin();
                        Console.ReadKey();
                    }
                    else if (currentSelection == 3)
                    {
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice");
                        Console.ReadKey();
                    }
                }
            }
        }

        /* ------------ Sign up/Sign in Menu ----------*/
        static void signup()
        {
            SignIn s1 = new SignIn();
            Console.Write("Enter Username:");
            s1.username = Console.ReadLine();
            if (s1.is_username_exist(s1.username))
            {
                Console.WriteLine("Username already exists");
                return;
            }

            Console.Write("Enter Password:");
            s1.password = Console.ReadLine();

            int numbb = Console.CursorTop;
        input_phone:
            Console.SetCursorPosition(0, numbb);
            printspace();
            Console.SetCursorPosition(0, numbb);
            Console.Write("Enter Phone Number:");
            s1.contactNumber = Console.ReadLine();
            if (!(s1.isInteger(s1.contactNumber)))
            {
                Console.WriteLine("Invalid input! Please enter a valid Phone Number. ");
                Console.ReadKey();
                goto input_phone;
            }
            if (s1.is_phone_exist(s1.contactNumber))
            {
                Console.WriteLine("Phone Number already in use");
                return;
            }

            int numb1 = Console.CursorTop;
        input_email:
            Console.SetCursorPosition(0, numb1);
            printspace();
            Console.SetCursorPosition(0, numb1);
            Console.Write("Enter Email:");
            s1.Email = Console.ReadLine();

            Regex emailRegex = new Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
            if (!emailRegex.IsMatch(s1.Email))
            {
                Console.WriteLine("Invalid email address.");
                Console.ReadKey();
                goto input_email;
            }
            if (s1.is_email_exist(s1.Email))
            {
                Console.WriteLine("Email already in use");
                return;
            }

            int numb2 = Console.CursorTop;
        input_role:
            Console.SetCursorPosition(0, numb2);
            printspace();
            Console.SetCursorPosition(0, numb2);
            Console.Write("Enter role(admin/student):");
            s1.Role = Console.ReadLine();
            if (!(s1.isString(s1.Role)))
            {
                Console.WriteLine("Invalid input! Please enter a valid Role. ");
                Console.ReadKey();
                goto input_role;
            }

            SignIn.s.Add(s1);
            Storinglogindata(s1);
            Console.Write("Sign up Successfully");
        }

        static void Storinglogindata(SignIn s1)
        {

            string path = "C:\\OOP\\OOP Lab 1\\management system\\login.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(s1.username + "," + s1.password + "," + s1.contactNumber + "," + s1.Email + "," + s1.Role);
            file.Flush();
            file.Close();
        }

        static void signin()
        {
            string un, p;
            Console.Write("Enter Username:");
            un = Console.ReadLine();
            Console.Write("Enter Password:");
            p = Console.ReadLine();
            SignIn s1 = new SignIn(un, p);

            if (s1.is_valid_user(s1))
            {
                string role1 = s1.get_role(un);

                if (role1 == "Admin" || role1 == "admin")
                {
                    Console.WriteLine();
                    Console.WriteLine("        Welcome, " + un + "!");
                    AdminMenu();
                    Console.ReadKey();
                }
                else if (role1 == "Customer" || role1 == "Customer")
                {
                    Console.WriteLine();
                    Console.WriteLine("        Welcome, " + un + "!");
                    CustomerMenu();
                    Console.ReadKey();

                }
                else
                {
                    Console.WriteLine("Invalid role");
                }
            }
            else
            {
                Console.WriteLine("Incorrect Username or Password");
            }
        }
        static void printspace()
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 200; j++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

       static void CustomerMenu()
        {
            int option = 0;
            Customer c = new Customer();
            List<Product> p = new List<Product>();
            Product p1 = new Product();
            while (option != 6)
            {
                Console.Clear();
                Menu1();
                Console.WriteLine("Enter option:");
                option = int.Parse(Console.ReadLine());
                if (option == 1)
                {
                    view_products(p);
                    Console.ReadKey();
                }
                else if (option == 2)
                {
                    Console.Write("Enter Product Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter Quantity: ");
                    int quantity = int.Parse(Console.ReadLine());
                    c.BuyProduct(p1, quantity);
                }
                else if (option == 3)
                {
                    Console.WriteLine("Invoice:");
                    c.GenerateInvoice(p);



                }
            }       }
        static void AdminMenu()
        {
            int option = 0;
            List<Product> product_list = new List<Product>();
            while (option != 6)
            {
                Console.Clear();
                Menu2();
                Console.WriteLine("Enter option:");
                option = int.Parse(Console.ReadLine());
                if (option == 1)
                {
                    Add_Product(product_list);
                    Console.ReadKey();
                }
                else if (option == 2)
                {
                    view_products(product_list);
                    Console.ReadKey();

                }
                else if (option == 3)
                {
                    Product np = find_highest_price(product_list);
                    Console.WriteLine("The product is " + np.product_name + "with the highest price " + np.product_price);
                    Console.ReadKey();

                }
                else if (option == 4)
                {
                    view_sales_tax(product_list);
                    Console.ReadKey();

                }
                else if (option == 5)
                {
                    product_to_b_ordered(product_list);
                    Console.ReadKey();

                }
                else if (option < 1 || option > 6)
                {
                    Console.WriteLine("Invalid Choice!");
                    Console.ReadKey();

                }

            }
            Console.Read();
        }

        static void Menu1()
        {
            Console.WriteLine("1. Add Product");
            Console.WriteLine("2. View All Product");
            Console.WriteLine("3. Find Product with the Highest Unit Price");
            Console.WriteLine("4. View Sales Tax of All Products");
            Console.WriteLine("5. Products to be Ordered");
        } 
        static void Menu2()
        {
            Console.WriteLine("1. View All Product");
            Console.WriteLine("2. Buy Product");
            Console.WriteLine("3. Generate Invoice");
        }


        static void Add_Product(List<Product> product_list)
        {
            Product p1 = new Product();
            Console.WriteLine("Enter Product Name:");
            p1.product_name = Console.ReadLine();
            Console.WriteLine("Enter Product Category:");
            p1.product_category = Console.ReadLine();
            Console.WriteLine("Enter Product Price:");
            p1.product_price = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Stock Quantity:");
            p1.stock_quantity = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Minimum Stock Quantity:");
            p1.minimum_stock_quantity = int.Parse(Console.ReadLine());
            product_list.Add(p1);

        }

        static void view_products(List<Product> product_list)
        {
            Console.Clear();
            Console.WriteLine("Products:");
            for (int i = 0; i < product_list.Count; i++)
            {
                product_list[i].display_product();
            }
        }

        static Product find_highest_price(List<Product> product_list)
        {
            int highest_price = product_list[0].product_price;
            Product Highest_price = product_list[0];
            for (int i = 0; i < product_list.Count; i++)
            {
                if (product_list[i].product_price > highest_price)
                {
                    Highest_price = product_list[i];
                }
            }
            return Highest_price;
        }

        static void view_sales_tax(List<Product> product_list)
        {
            int sale_tax = 0;
            foreach (Product i in product_list)
            {
                sale_tax = i.Sales_tax();
                Console.WriteLine(i.product_name + ": Rs. " + sale_tax);
            }
            Console.ReadKey();
        }

        static void product_to_b_ordered(List<Product> product_list)
        {
            Console.Clear();
            foreach (Product i in product_list)
            {
                if (i.IsNeeded())
                {
                    Console.WriteLine(i.product_name);
                }
            }
            Console.ReadKey();
        }
    }
}
