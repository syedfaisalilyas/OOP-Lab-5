﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UAMSS.DL;


namespace UAMSS.BL
{
    class StudentBL
    {
            public string name;
            public int age;
            public double fscMarks;
            public double ecatMarks;
            public double merit;
            public StudentDL sd = new StudentDL();
            static public List<DegreeProgramBL> preferences = new List<DegreeProgramBL>();
            static public DegreeProgramBL RegisteredProgram = new DegreeProgramBL();
            static public List<SubjectBL> registeredSubjects = new List<SubjectBL>();
            public bool isRegistered = false;
            public StudentBL() { }

            public StudentBL(string name, int age, double fscMarks, double ecatMarks)
            {
                this.name = name;
                this.age = age;
                this.fscMarks = fscMarks;
                this.ecatMarks = ecatMarks;

            }

            public StudentBL(string name, int age, double fscMarks, double ecatMarks, double merit)
            {
                this.name = name;
                this.age = age;
                this.fscMarks = fscMarks;
                this.ecatMarks = ecatMarks;
                this.merit = merit;

            }
            public double calculateMerit()
            {
                merit = (fscMarks * 0.6 + ecatMarks * 0.4);
                return merit;
            }

       static public int getcredithours()
        {
            int count = 0;
            for (int i = 0; i < registeredSubjects.Count; i++)
            {
                count += registeredSubjects[i].creditHours;
            }
            return count;
        }
        public float CalculateFee()
            {
                int ch = getcredithours();
                float fee = ch * 2000;
                return fee;
            }
        }
    }
