﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UAMSS.BL
{
    class DegreeProgramBL
    {
        public string degreeName;
        public float degreeDuration;
        public int seats;
        public double merit;
        public List<SubjectBL> subjects = new List<SubjectBL>();

        public DegreeProgramBL() { }
        public DegreeProgramBL(string degreeName, float degreeDuration, int seats)
        {
            this.degreeName = degreeName;
            this.degreeDuration = degreeDuration;
            this.seats = seats;

        }
        public DegreeProgramBL(string degreeName)
        {
            this.degreeName = degreeName;

            this.degreeDuration = 0;
            this.seats = 0;
        }
    }
}

