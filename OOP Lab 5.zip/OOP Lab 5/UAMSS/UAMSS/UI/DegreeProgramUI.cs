﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UAMSS.BL;

namespace UAMSS.UI
{
    class DegreeProgramUI
    {
        public void ViewDegreeProgram(List<DegreeProgramBL> degreeProgram)
        {
            foreach (DegreeProgramBL d1 in degreeProgram)
            {
                Console.WriteLine(d1.degreeName);
                Console.WriteLine(d1.degreeDuration);
                Console.WriteLine(d1.degreeName);
            }
        }
        public DegreeProgramBL FindDegree(string dName, List<DegreeProgramBL> degreeProgram)
        {
            DegreeProgramBL d0 = new DegreeProgramBL();
            foreach (DegreeProgramBL d1 in degreeProgram)
            {
                if (d1.degreeName == dName)
                {
                    d0 = d1;
                    return d0;
                }
            }
            return null;
        }

        public DegreeProgramBL AddDegreeProgram()
        {

            Console.WriteLine("Enter degree name");
            string degreeName = Console.ReadLine();
            Console.WriteLine("Enter degree duaration");
            int degreeDuration = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter how many seats are available:");
            int seats = int.Parse(Console.ReadLine());
            DegreeProgramBL d1 = new DegreeProgramBL(degreeName, degreeDuration, seats);
            return d1;

        }
    }
}
