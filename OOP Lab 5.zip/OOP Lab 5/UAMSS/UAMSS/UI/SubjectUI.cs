﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UAMSS.BL;
using UAMSS.DL;

namespace UAMSS.UI
{
    class SubjectUI
    {
        
        public void AddSubjectForStudent(List<StudentBL> students, string stuName, string subCode)
        {
            StudentUI S = new StudentUI();
            bool isPresent = S.isStudentPresent(stuName, students);
            if (isPresent == true)
            {
                StudentDL s1 = new StudentDL();
                bool isRegister = StudentDL.RegisterSubject(subCode);
                if (isRegister == true)
                {
                    Console.WriteLine("Successfully register!");
                }
                else
                {
                    Console.WriteLine("Can't register!");
                }
            }
        }
        public SubjectBL AddSubject()
        {
            Console.WriteLine("Enter subject code");
            string subCode = Console.ReadLine();
            Console.WriteLine("Enter subject type");
            string subType = Console.ReadLine();
            Console.WriteLine("Enter credit hours:");
            int subCH = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter subject fee:");
            int subFee = int.Parse(Console.ReadLine());
            SubjectBL s1 = new SubjectBL(subCode, subType, subCH, subFee);
            return s1;
        }

    }
}
