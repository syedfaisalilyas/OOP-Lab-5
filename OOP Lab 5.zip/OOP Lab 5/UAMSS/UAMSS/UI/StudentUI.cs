﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UAMSS.BL;
using UAMSS.DL;

namespace UAMSS.UI
{
    class StudentUI
    {
        public void RegisterStudentForSpecificSubject(List<StudentBL> students)
        {
            Console.WriteLine("Enter Student Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Subject Code:");
            string subjectcode = Console.ReadLine();

        }
        public bool isStudentPresent(string studentName, List<StudentBL> student)
        {
            for (int i = 0; i < student.Count; i++)
            {
                if (studentName == student[i].name)
                {
                    return true;
                }
            }
            return false;
        }
        public void CalculateFees(List<StudentBL> student)
        {
            float fees;

            for (int i = 0; i < student.Count; i++)
            {
                fees = student[i].CalculateFee();
                Console.WriteLine("{0} student fees is {1}", student[i].name, fees);
            }
        }
        public void viewStudentsOfSpecificDegree(string degreeName, List<StudentBL> students)
        {
            foreach (StudentBL s1 in students)
            {
                if (StudentBL.RegisteredProgram.degreeName == degreeName)
                {
                    Console.WriteLine(s1.name);
                    Console.WriteLine(s1.fscMarks);
                    Console.WriteLine(s1.ecatMarks);
                }

            }
        }
        public void ViewAddmittedStudents(List<StudentBL> students)
        {
            foreach (StudentBL s1 in students)
            {
                Console.Write(s1.name);
                Console.WriteLine(StudentBL.RegisteredProgram);
            }
        }
        public int Menu()
        {
            int choice = 0;
            Console.WriteLine("1-Add student");
            Console.WriteLine("2-Add Degree Program");
            Console.WriteLine("3-Add Subject");
            Console.WriteLine("4-Add Preferences");
            choice = int.Parse(Console.ReadLine());
            return choice;
        }

        public StudentBL AddStudent()
        {
            int fMarks, eMarks;

            Console.WriteLine("Enter name of the student: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter age of the student:");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter FSC marks of student: ");
            fMarks = int.Parse(Console.ReadLine());
            while (!(fMarks <= 1100))
            {
                Console.WriteLine("Enter FCS marks");
                fMarks = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Enter ECAT marks");
            eMarks = int.Parse(Console.ReadLine());
            while (!(eMarks <= 400))
            {
                Console.WriteLine("Enter FCS marks");
                eMarks = int.Parse(Console.ReadLine());
            }
            StudentBL student = new StudentBL(name, age, fMarks, eMarks);

            Console.WriteLine(student.merit);
            return student;
        }

        public StudentBL AddPreferences(List<DegreeProgramBL> degreeProgram)
        {
            int fMarks, eMarks;
            string dname = "";
            Console.WriteLine("Enter name of the student: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter age of the student:");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter FSC marks of student: ");
            fMarks = int.Parse(Console.ReadLine());
            while (fMarks > 1100)
            {
                Console.WriteLine("Enter FCS marks");
                fMarks = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Enter ECAT marks");
            eMarks = int.Parse(Console.ReadLine());
            while (eMarks > 400)
            {
                Console.WriteLine("Enter FCS marks");
                eMarks = int.Parse(Console.ReadLine());
            }

            StudentBL s1 = new StudentBL(name, age, fMarks, eMarks);
            DegreeProgramUI dp = new DegreeProgramUI();
            dp.ViewDegreeProgram(degreeProgram);

            Console.WriteLine("Enter degree name");
            dname = Console.ReadLine();
            DegreeProgramBL degreeProgram1 = dp.FindDegree(dname, degreeProgram);

            if (degreeProgram1 != null)
            {
               StudentDL.AddPreferenceOfStudent(degreeProgram1);
                return s1;
            }
            return null;
        }


        public List<StudentBL> PrepareMeritList(List<StudentBL> students, int seats)
        {
            List<StudentBL> selectedStudents = new List<StudentBL>();
            students.Sort();
            foreach (StudentBL student in students)
            {
                if (selectedStudents.Count >= seats)
                {
                    break; // All seats are filled
                }
                /* foreach (DegreeProgram p in student.preferences)
                 {
                     // Enroll the student in the first program with available seats
                     student.RegisteredProgram = p;
                     selectedStudents.Add(student);

                 }*/

            }
            return selectedStudents;
        }

        public List<StudentBL> GenerateMeritList(List<StudentBL> student)
        {
            DegreeProgramBL degreeProgram = new DegreeProgramBL();
            List<StudentBL> selectedStudents = PrepareMeritList(student, degreeProgram.seats);
            return selectedStudents;
        }

        public void ViewStudent(List<StudentBL> student)
        {
            if (student == null)
            {
                Console.WriteLine("No students are registered yet");
            }
            else
            {
                foreach (StudentBL s0 in student)
                {
                    Console.WriteLine(s0.name);
                    Console.WriteLine(s0.age);
                    Console.WriteLine(s0.fscMarks);
                    Console.WriteLine(s0.ecatMarks);
                    foreach (DegreeProgramBL d1 in StudentBL.preferences)
                    {
                        Console.WriteLine(d1.degreeName);
                        Console.WriteLine(d1.degreeDuration);
                    }
                }
            }
        }
    }
}
