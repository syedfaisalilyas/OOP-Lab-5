﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UAMSS.BL;
using UAMSS.DL;
using UAMSS.UI;

namespace UAMSS
{
        class Program
        {
            static void Main(string[] args)
            {
                StudentBL stu = new StudentBL();
                StudentDL SS = new StudentDL();
                DegreeProgramBL dgp = new DegreeProgramBL();
                SubjectBL sbj = new SubjectBL();
                List<StudentBL> listOfStudents = new List<StudentBL>();
                List<DegreeProgramBL> listOfdegreePrograms = new List<DegreeProgramBL>();
                StudentUI S = new StudentUI();
                DegreeProgramUI DP = new DegreeProgramUI();
                SubjectUI su = new SubjectUI();
                List<SubjectBL> listOfSubjects = new List<SubjectBL>();
                while (true)
                {
                    int choice = S.Menu();
                    if (choice == 1)
                    {

                        if (S.AddPreferences(listOfdegreePrograms) != null)
                        {
                            stu = S.AddPreferences(listOfdegreePrograms);
                            listOfStudents.Add(stu); 
    
                    }
                        /*  stu = AddStudent();
                          listOfStudents.Add(stu);*/
                    }
                    else if (choice == 2)
                    {
                        dgp =   DP.AddDegreeProgram();
                        listOfdegreePrograms.Add(dgp);
                    }
                    else if (choice == 3)
                    {
                        sbj = su.AddSubject();
                        listOfSubjects.Add(sbj);
                    }
                    else if (choice == 4)
                    {
                        /*List<Student> AddmittedStudents = GenerateMeritList(listOfStudents);

                         ViewAddmittedStudents(AddmittedStudents);*/
                        StudentDL.GenerateMeritList();
                    }
                    else if (choice == 5)
                    {
                        Console.WriteLine("Enter Degree program:");
                        string degree = Console.ReadLine();
                        S.viewStudentsOfSpecificDegree(degree, listOfStudents);
                        /*ViewStudent(listOfStudents);*/
                    }
                    else if (choice == 6)
                    {
                        /*ViewDegreeProgram(listOfdegreePrograms);*/
                        S.RegisterStudentForSpecificSubject(listOfStudents);
                    }
                    else if (choice == 7)
                    {
                        S.CalculateFees(listOfStudents);
                    }
                    else if (choice == 8)
                    {
                        break;
                    }
                }
            }
         

           



            

            
            



        }
    }

