﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UAMSS.BL;

namespace UAMSS.DL
{
    class StudentDL
    {

       static public void AddPreferenceOfStudent(DegreeProgramBL d1)
        {
           StudentBL.preferences.Add(d1);
        }
       static public bool RegisterSubject(string subCode)
        {
            bool isSubjectRegister = false;
            int creditHour = StudentBL.getcredithours();
            if (creditHour == 9)
            {
                isSubjectRegister = false;
            }
            else
            {
                for (int i = 0; i < StudentBL.preferences.Count; i++)
                {
                    if (isSubjectRegister == true && StudentBL.RegisteredProgram.degreeName == StudentBL.preferences[i].degreeName)
                    {
                        for (int j = 0; j < StudentBL.registeredSubjects.Count; j++)
                        {
                            StudentBL.registeredSubjects.Add(StudentBL.preferences[i].subjects[j]);
                            isSubjectRegister = true;
                        }
                    }
                }
            }
            return isSubjectRegister;
        }


       static public void GenerateMeritList()
        {
          StudentBL sb = new StudentBL();
            double merit = sb.calculateMerit();
            int count = 0;
            for (int i = 0; i < StudentBL.preferences.Count; i++)
            {
                if (merit >= StudentBL.preferences[i].merit)
                {
                    count++;
                   StudentBL.RegisteredProgram = StudentBL.preferences[i];
                    sb.isRegistered = true;
                    break;
                }
            }
            if (count == 1)
            {
                Console.WriteLine(" {0} got admission in {1}", sb.name,StudentBL.RegisteredProgram.degreeName);
            }

            if (sb.isRegistered == false)
            {
                Console.WriteLine(" {0} did not get admission", sb.name);
            }
        }

    }
}
